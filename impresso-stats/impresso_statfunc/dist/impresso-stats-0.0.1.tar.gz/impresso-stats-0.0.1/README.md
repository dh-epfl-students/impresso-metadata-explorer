# impresso-metadata-explorer

## Package installation
1. create a virtual environment (pyenv) : `$ pyenv virtualenv 3.6.9 <env-name>`
2. activate it : `$ pyenv activate <env-name>`
3. install packages : `$ pip install requirements-basic.txt`

